<?php

namespace Tests\Feature\Registration;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class RegistrationTest extends TestCase
{
    use RefreshDatabase;
    public function test_registration_page_loads(): void
    {
        $response = $this->get('/register');
        $response->assertSee('Register');        
        $response->assertStatus(200);
    }

    public function test_registration_page_contains_required_inputs(): void
    {
        $response = $this->get('/register');
        $response->assertSee('Name');
        $response->assertSee('Email');
        $response->assertSee('Password');
        $response->assertSee('Confirm password');
    }

    public function test_registration_without_input_values(): void
    {
        $response = $this->post('/register', [
            'name' => '',
            'email' => '',
            'password' => '',
            'password_confirmation' => '',
        ]);

        $response->assertStatus(302);
        $response->assertSessionHasErrors(['name', 'email', 'password']);
    }

    public function test_registration_with_invalid_email(): void
    {
        $response = $this->post('/register', [
            'name' => 'John Doe',
            'email' => 'temp',
            'password' => '12345678',
            'password_confirmation' => '12345678',
        ]);

        $response->assertStatus(302);
        $response->assertSessionHasErrors(['email']);
    }

    public function test_registration_with_invalid_password(): void
    {
        $response = $this->post('/register', [
            'name' => 'John Doe',
            'email' => 'temp@test.com',
            'password' => '1234',
            'password_confirmation' => '1234',
        ]);

        $response->assertStatus(302);
        $response->assertSessionHasErrors(['password']);
    }

    public function test_registration_with_password_mismatch(): void
    {
        $response = $this->post('/register', [
            'name' => 'John Doe',
            'email' => 'temp@test.com',
            'password' => '12345678',
            'password_confirmation' => '123456789',
        ]);

        $response->assertStatus(302);
        $response->assertSessionHasErrors(['password']);
    }

    public function test_registration_with_valid_credentials(): void
    {
        $response = $this->post('/register', [
            'name' => 'John Doe',
            'email' => 'temp@test.com',
            'password' => '12345678',
            'password_confirmation' => '12345678',
        ]);

        $response->assertStatus(302);
        $response->assertSessionHasNoErrors();
    }

    public function test_registration_redirects_to_home_page(): void
    {
        $response = $this->post('/register', [
            'name' => 'John Doe',
            'email' => 'temp@test.com',
            'password' => '12345678',
            'password_confirmation' => '12345678',
        ]);

        $response->assertStatus(302);
        $this->assertDatabaseHas('users', [
            'email' => 'temp@test.com',
            'name' => 'John Doe',
        ]);
        
        $response->assertRedirect('/user/posts');
    }

    public function test_user_authenticated_after_registration(): void
    {
        $response = $this->post('/register', [
            'name' => 'John Doe',
            'email' => 'temp@test.com',
            'password' => '12345678',
            'password_confirmation' => '12345678',
        ]);
        
        $this->assertAuthenticated();
    }
}
