<?php

namespace Tests\Feature\Users;

use App\Models\Post;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class PostsTest extends TestCase
{
    use RefreshDatabase;

    public function test_guests_cant_access_posts_page(): void
    {
        $response = $this->get('/user/posts');

        $response->assertStatus(302);
        $response->assertRedirect('/login');
    }

    public function test_guests_cant_access_create_posts_page(): void
    {
        $response = $this->get('/user/posts/create');
        $response->assertStatus(302);
        $response->assertRedirect('/login');
    }

    public function test_guests_cant_submit_create_post_form(): void
    {
        $response = $this->post('/user/posts', [
            'title' => 'Test Title',
            'content' => 'Test Content',
        ]);

        $response->assertStatus(302);
        $response->assertRedirect('/login');
    }

    public function test_guests_can_access_edit_post_form(): void
    {
        $post = Post::factory()->create();
        $response = $this->get('/user/posts/1/edit');
        $response->assertStatus(302);
        $response->assertRedirect('/login');
    }

    public function test_guests_cant_submit_update_post_form(): void
    {
        $post = Post::factory()->create();
        $response = $this->put('/user/posts/1', [
            'title' => 'Test Title',
            'content' => 'Test Content',
        ]);

        $response->assertStatus(302);
        $response->assertRedirect('/login');
    }

    public function test_guests_cant_delete_post(): void
    {
        $post = Post::factory()->create();
        $response = $this->delete('/user/posts/1');
        $response->assertStatus(302);
        $response->assertRedirect('/login');
    }

    public function test_users_can_access_posts_page(): void
    {
        $user = $this->signIn();
        $response = $this->get('/user/posts');
        $response->assertStatus(200);
    }

    public function test_users_see_no_posts_found_message(): void
    {
        $user = $this->signIn();
        $response = $this->get('/user/posts');
        $response->assertSeeText('No posts found.');
    }

    public function test_users_see_add_post_button(): void
    {
        $user = $this->signIn();
        $response = $this->get('/user/posts');
        $response->assertSee('Add post');
    }

    public function test_users_can_access_create_post_page(): void
    {
        $user = $this->signIn();
        $response = $this->get('/user/posts/create');
        $response->assertStatus(200);
    }

    public function test_users_can_submit_create_post_form(): void
    {
        $user = $this->signIn();
        $response = $this->post('/user/posts', [
            'title' => 'Test Title',
            'content' => 'Test Content',
        ]);

        $response->assertStatus(302);
        $response->assertRedirect('/user/posts');
    }

    public function test_users_can_submit_create_post_form_and_exists_in_database(): void
    {
        $user = $this->signIn();
        $response = $this->post('/user/posts', [
            'title' => 'Test Title',
            'content' => 'Test Content',
        ]);

        $this->assertDatabaseHas('posts', [
            'title' => 'Test Title',
            'content' => 'Test Content',
        ]);
    }

    public function test_users_can_submit_create_post_form_and_see_it_in_posts_page(): void
    {
        $user = $this->signIn();
        $response = $this->post('/user/posts', [
            'title' => 'Test Title',
            'content' => 'Test Content',
        ]);

        $response = $this->get('/user/posts');
        $response->assertSee('Test Title');
    }

    public function test_users_can_access_edit_post_form(): void
    {
        $user = $this->signIn();
        $post = Post::factory()->create(
            [
                'user_id' => $user->id,
            ]
        );
        $response = $this->get('/user/posts/1/edit');
        $response->assertStatus(200);
    }

    public function test_users_cant_access_edit_post_form_of_other_user(): void
    {
        $user = $this->signIn();
        $post = Post::factory()->create();
        $response = $this->get('/user/posts/1/edit');
        $response->assertStatus(403);
    }

    public function test_users_cant_submit_update_post_form_of_other_user(): void
    {
        $user = $this->signIn();
        $post = Post::factory()->create();
        $response = $this->put('/user/posts/1', [
            'title' => 'Updated Title',
            'content' => 'Updated Content',
        ]);

        $response->assertStatus(403);
    }
    
    public function test_users_can_see_post_own_edit_form(): void
    {
        $user = $this->signIn();
        $post = Post::factory()->create(
            [
                'user_id' => $user->id,
                'title' => 'Test Title',
                'content' => 'Test Content',
            ]
        );

        $response = $this->get('/user/posts/1/edit');
        $response->assertSee('Test Title');
        $response->assertSee('Test Content');
    }

    public function test_users_can_submit_update_post_form(): void
    {
        $user = $this->signIn();
        $post = Post::factory()->create(
            [
                'user_id' => $user->id,
            ]
        );

        $response = $this->put('/user/posts/1', [
            'title' => 'Updated Title',
            'content' => 'Updated Content',
        ]);

        $response->assertStatus(302);
    }

    public function test_users_can_submit_update_post_form_and_exists_in_database(): void
    {
        $user = $this->signIn();
        $post = Post::factory()->create(
            [
                'user_id' => $user->id,
            ]
        );

        $response = $this->put('/user/posts/1', [
            'title' => 'Updated Title',
            'content' => 'Updated Content',
        ]);

        $this->assertDatabaseHas('posts', [
            'title' => 'Updated Title',
            'content' => 'Updated Content',
        ]);
    }

    public function test_users_can_submit_update_post_form_and_see_success_message(): void
    {
        $user = $this->signIn();
        $post = Post::factory()->create(
            [
                'user_id' => $user->id,
            ]
        );

        $response = $this->put('/user/posts/1', [
            'title' => 'Updated Title',
            'content' => 'Updated Content',
        ]);

        $response->assertSessionHas('success');
    }

    public function test_users_can_delete_own_post(): void
    {
        $user = $this->signIn();
        $post = Post::factory()->create(
            [
                'user_id' => $user->id,
            ]
        );

        $response = $this->delete('/user/posts/1');
        $response->assertStatus(302);
    }

    public function test_users_cant_delete_other_user_post(): void
    {
        $user = $this->signIn();
        $post = Post::factory()->create();

        $response = $this->delete('/user/posts/1');
        $response->assertStatus(403);
    }

    public function test_users_can_view_post(): void
    {
        $user = $this->signIn();
        $post = Post::factory()->create(
            [
                'user_id' => $user->id,
            ]
        );

        $response = $this->get('/user/posts/1');
        $response->assertSee($post->title);
        $response->assertSee($post->content);
    }

    public function test_users_cant_view_other_user_post(): void
    {
        $user = $this->signIn();
        $post = Post::factory()->create();

        $response = $this->get('/user/posts/1');
        $response->assertStatus(403);
    }
    
    private function signIn()
    {
        $user = User::factory()->create();
        $this->actingAs($user);
        return $user;
    }
}
