<?php

namespace Tests\Feature\Auth;

use App\Models\Post;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class LoginTest extends TestCase
{
    use RefreshDatabase;

    public function test_login_page_loads(): void
    {
        $response = $this->get('/login');
        $response->assertSee('Login');
        $response->assertStatus(200);
    }

    public function test_login_page_contains_required_inputs(): void
    {
        $response = $this->get('/login');
        $response->assertSee('Email');
        $response->assertSee('Password');
    }

    public function test_login_without_input_values(): void
    {
        $response = $this->post('/login', [
            'email' => '',
            'password' => '',
        ]);

        $response->assertStatus(302);
        $response->assertSessionHasErrors(['email', 'password']);
    }

    public function test_login_with_invalid_credentials(): void
    {
        $response = $this->post('/login', [
            'email' => 'temp@test.com',
            'password' => '123456',
        ]);

        $response->assertStatus(302);
        $response->assertSessionHasErrors(['email']);
    }

    public function test_login_with_valid_credentials(): void
    {
        $user = User::factory()->create([
            'email' => 'hello@test.com',
            'password' => bcrypt('P@ssword'),
        ]);

        $response = $this->post('/login', [
            'email' => 'hello@test.com',
            'password' => 'P@ssword',
        ]);

        $response->assertStatus(302);
        $response->assertSessionHasNoErrors();
        $response->assertRedirect(RouteServiceProvider::DASHBOARD);
    }

    public function test_home_page_contains_user_links(): void
    {
        $user = User::factory()->create();
        $response = $this->actingAs($user)->get('/');
        $response->assertSee('Logout');
        $response->assertSee('My posts');
    }

    public function test_home_page_does_not_contain_guest_links(): void
    {
        $response = $this->get('/');
        $response->assertDontSee('Logout');
        $response->assertDontSee('My posts');
    }

    public function test_logout_user(): void
    {
        $user = User::factory()->create();
        $response = $this->actingAs($user)->post('/logout');

        $response->assertStatus(302);
        $response->assertRedirect('/');
    }

    public function test_user_pages_redirects_to_login_page(): void
    {
        Post::factory()->create();

        $response = $this->get('/user/posts');
        $response->assertStatus(302);
        $response->assertRedirect('/login');

        $response = $this->get('/user/posts/create');
        $response->assertStatus(302);
        $response->assertRedirect('/login');

        $response = $this->get('/user/posts/1/edit');
        $response->assertStatus(302);
    }

    public function test_logout_redirects_to_login_page(): void
    {
        $response = $this->post('/logout');
        $response->assertStatus(302);
        $response->assertRedirect('/login');
    }

    public function test_user_pages_can_be_accessed_after_login(): void
    {
        $user = User::factory()->create();
        Post::factory()->create([
                'user_id' => $user->id,
            ]
        );
        
        $response = $this->actingAs($user)->get('/user/posts');
        $response->assertStatus(200);

        $response = $this->actingAs($user)->get('/user/posts/create');
        $response->assertStatus(200);

        $response = $this->actingAs($user)->get('/user/posts/1/edit');
        $response->assertStatus(200);
    }

    public function test_logged_in_user_cant_access_login_and_register_pages(): void
    {
        $user = User::factory()->create();
        $response = $this->actingAs($user)->get('/login');
        $response->assertStatus(302);
        $response->assertRedirect(RouteServiceProvider::HOME);

        $response = $this->actingAs($user)->get('/register');
        $response->assertStatus(302);
        $response->assertRedirect(RouteServiceProvider::HOME);
    }
}
