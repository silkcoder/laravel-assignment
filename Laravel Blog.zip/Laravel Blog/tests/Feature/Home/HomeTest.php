<?php

namespace Tests\Feature\Home;

use App\Models\Post;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class HomeTest extends TestCase
{
    use RefreshDatabase;

    public function test_home_page_loads_and_has_title(): void
    {
        $response = $this->get('/');
        $response->assertStatus(200);
        $response->assertSeeText('Blogs');
    }

    public function test_home_page_contains_no_post_found_text(): void
    {
        $response = $this->get('/');
        $response->assertSeeText('No posts found.');
    }

    public function test_home_page_contains_guest_links(): void
    {
        $response = $this->get('/');
        $response->assertSeeText('Register');
        $response->assertSeeText('Login');
    }

    public function test_home_page_does_not_contain_user_links(): void
    {
        $response = $this->get('/');
        $response->assertDontSee('My Posts');
        $response->assertDontSee('Logout');
    }


    public function test_home_page_contains_new_post(): void
    {
        Post::factory()->create([
                'title' => 'New Post',
                'content' => 'This is a new post content',
            ]
        );

        $response = $this->get('/');
        $response->assertSee('New Post');
        $response->assertSeeText('This is a new post content');
    }

    public function test_home_page_contains_multiple_posts(): void
    {
        Post::factory()->create([
                'title' => 'Post 1',
                'content' => 'This is post 1 content',
            ]
        );

        Post::factory()->create([
                'title' => 'Post 2',
                'content' => 'This is post 2 content',
            ]
        );

        $response = $this->get('/');
        $response->assertSee('Post 1');
        $response->assertSeeText('This is post 1 content');
        $response->assertSee('Post 2');
        $response->assertSeeText('This is post 2 content');
    }


    public function test_home_page_contains_pagination(): void
    {
        Post::factory()->count(20)->create();
        $response = $this->get('/');
        $response->assertSee('1');
        $response->assertSee('2');
        $response->assertSee('Next');
        $response->assertSee('Previous');
    }


    public function test_home_page_pagination_works(): void
    {
        Post::factory()->count(20)->create();
        $response = $this->get('/?page=2');
        $response->assertSee('1');
        $response->assertSee('2');
        $response->assertSee('Next');
        $response->assertSee('Previous');
    }

    public function test_home_page_contains_correct_user_name(): void
    {
        $user = User::factory()->create([
                'name' => 'John Doe',
            ]
        );

        Post::factory()->create([
                'user_id' => $user->id,
            ]
        );
        
        $response = $this->get('/');
        $response->assertSee($user->name);
    }
}
