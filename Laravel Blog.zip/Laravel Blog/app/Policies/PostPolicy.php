<?php

namespace App\Policies;

use App\Models\Post;
use App\Models\User;
use Illuminate\Auth\Access\Response;

class PostPolicy
{
    /*
        * Determine if the given post can be viewed by the user.
        *
        * @param  \App\Models\User  $user
        * @param  \App\Models\Post  $post
        * @return bool
    */
    public function view(User $user, Post $post)
    {
        return $user->id === $post->user_id;            
    }

    /*
        * Determine if the given post can be edit by the user.
        *
        * @param  \App\Models\User  $user
        * @param  \App\Models\Post  $post
        * @return bool
    */
    public function edit(User $user, Post $post)
    {
        return $user->id === $post->user_id;
    }

    /*
        * Determine if the given post can be updated by the user.
        *
        * @param  \App\Models\User  $user
        * @param  \App\Models\Post  $post
        * @return bool
    */
    public function update(User $user, Post $post)
    {
        return $user->id === $post->user_id;
    }

    /*
        * Determine if the given post can be deleted by the user.
        *
        * @param  \App\Models\User  $user
        * @param  \App\Models\Post  $post
        * @return bool
    */
    public function delete(User $user, Post $post)
    {
        return $user->id === $post->user_id;
    }
}
