<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\RegistrationRequest;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\Log;


class RegistrationController extends Controller
{
    /**
     * Show the registration form.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function create()
    {
        return view('auth.register');
    }

    /**
     * Store a new user.
     *
     * @param RegistrationRequest $registrationRequest
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(RegistrationRequest $registrationRequest)
    {
        try {
            // Create the user
            $user = User::create($registrationRequest->getData());

            // Sign the user in
            auth()->login($user);

            // Redirect to the home page
            return redirect(RouteServiceProvider::DASHBOARD);

        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return back()->withErrors(['An error occurred while creating the user.'])->withInput();
        }
    }
}
