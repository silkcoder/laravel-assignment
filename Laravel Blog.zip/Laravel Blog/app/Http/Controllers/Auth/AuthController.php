<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\LoginRequest;
use App\Providers\RouteServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;

class AuthController extends Controller
{
    /**
     * Show the login form.
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function loginForm()
    {
        return view('auth.login');
    }

    /**
     * Log the user in.
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function authenticate(LoginRequest $loginRequest)
    {
        try {
            // get all required data from the request
            $credentials = $loginRequest->getData();

            // Attempt to log the user in
            if (!auth()->attempt($credentials)) {
                return back()->withErrors([
                    'email' => 'Login failed, Invalid email or password.',
                ]);
            }
        } catch (\Exception $e) {
            return back()->withErrors(['An error occurred while logging in.'])->withInput();
        }

        // Redirect to the home page if the user is logged in
        return redirect(RouteServiceProvider::DASHBOARD);
    }

    /**
     * Log the user out.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function logout()
    {
        // Log the user out
        auth()->logout();

        // Redirect to the home page
        return redirect('/');
    }
}
