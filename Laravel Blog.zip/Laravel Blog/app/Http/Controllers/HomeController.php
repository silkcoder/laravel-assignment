<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;

class HomeController extends Controller
{
    /**
     * Show the home page.
     *
     * @param Request $request
     * @return \Illuminate\Contracts\View\View
     */
    public function __invoke(Request $request)
    {
        // Get the user id from the request if it exists
        $userId = $request->input('uid');

        // Get all posts with user relationship, and paginate them
        // If a user id is provided, filter the posts by that user
        $posts = Post::with('user')
            ->when($userId, function ($query) use ($userId) {
                $query->where('user_id', $userId);
            })->latest()
            ->paginate(10);

        // Return the home view with the posts
        return view('home', compact('posts'));
    }

    /**
     * Show the post page.
     *
     * @param String slug
     * @return \Illuminate\Contracts\View\View
     */
    public function post($slug)
    {
        // Get the post with user relationship
        $post = Post::with('user')->where('slug', $slug)->firstOrFail();

        // Return the post view with the post
        return view('post', compact('post'));
    }
}
