<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\PostRequest;
use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class PostController extends Controller
{
 
    /**
     * Display a listing of the posts.
     * 
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Contracts\View\View
     *  
     */
    public function index()
    {
        $posts = auth()->user()->posts()->latest()->paginate(10);
        return view('user.posts', compact('posts'));
    }

    /**
     * Show the form for creating a new post.
     *  
     * @return \Illuminate\Contracts\View\View
     */
    public function create()
    {
        return view('user.create');
    }

    public function show(Post $post)
    {
        //authorize the user to view the post
        $this->authorize('view', $post);
        return view('user.show', compact('post'));
    }

    /**
     * Store a newly created post in storage.
     * 
     * @param \App\Http\Requests\User\PostRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(PostRequest $request)
    {
        try {
            //create new post
            Post::create($request->getData());
            return redirect()->route('posts.index')->with('success', 'Post created successfully');
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return back()->withErrors(['An error occurred while creating the post.'])->withInput();
        }
    }

    /**
     * Show the form for editing the specified post.
     * 
     * @param \Illuminate\Http\Request $request
     * @param \App\Models\Post $post
     */
    public function edit(Request $request, Post $post)
    {
        //authorize the user to edit the post
        $this->authorize('edit', $post);

        //return the form view with the post
        return view('user.edit', compact('post'));
    }

    /**
     * Update the specified post in storage.
     * 
     * @param \App\Http\Requests\User\PostRequest $request
     * @param \App\Models\Post $post
     */
    public function update(PostRequest $request, Post $post)
    {
        //authorize the user to update the post
        $this->authorize('update', $post);

        try {            
            //update the post
            $post->update($request->getData());
            return back()->with('success', 'Post updated successfully.');
        } catch (\Exception $e) {
            //log the error and return back with an error message
            Log::error($e->getMessage());
            return back()->withErrors(['An error occurred while updating the post.'])->withInput();
        }
    }

    /**
     * Remove the specified post from storage.
     * 
     * @param \App\Models\Post $post
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(Post $post)
    {
        //authorize the user to delete the post
        $this->authorize('delete', $post);

        try {
            //delete the post
            $post->delete();
            return redirect()->route('posts.index')->with('success', 'Post deleted successfully.');
        } catch (\Exception $e) {
            //log the error and return back with an error message
            Log::error($e->getMessage());
            return back()->withErrors(['An error occurred while deleting the post.']);
        }
    }
}
