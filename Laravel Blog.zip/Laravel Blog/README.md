# How to instal
 - Unzip the folder
 - Update database credentials (DB_DATABASE, DB_USERNAME, DB_PASSWORD) values inside .env file
 - Run the command ```composer install``` to install dependencies
 - run the command ```php artisan migrate``` to create tables.
 - run the database seed command ```php artisan db:seed``` to seed tables.
 - If you are in a development environment with a web server, try accessing the application, else execute ```php artisan serve``` and access ```http://127.0.0.1:8000```
 -  You can optionally run ```php artisan test``` to run the unit tests.
 - You can login to the application using email ```blogger@test.com``` and password ```12345678```
 - Run time errors get logged into laravel.log file


## Database Design & Migrations
Following migration files are created.

- 2024_03_30_042853_create_users_table.php
- 2024_03_30_042900_create_posts_table.php


## Data Seeding
Seeders are added to populate users and posts tables.

## Authentication
Authentication added, You can login to the system using the following email and password

Email: ```blogger@test.com```
Password: ```12345678```

Password of all other seeded users is ```12345678```

Authorization implemented using policy.

## CRUD for Blog Posts
Authenticated users can perform CRUD operatons on own posts

## Middleware
Custom middleware ```CheckAuthenticated.php``` added to protect user routes.


## Blade Templates
Blade templates used to show the pages and forms.

## Eloquent Relationships
Required relationshops defined on models.

## Validation
Both client side (Javascript) and server side validations added for all forms.

## Basic Unit Testing
More than 50 unit tests included to ensure code quality. Please run ```php artisan test``` to run the tests.


