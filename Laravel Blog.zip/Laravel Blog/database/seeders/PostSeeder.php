<?php

namespace Database\Seeders;

use \App\Models\User;
use App\Models\Post;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PostSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        /*
        * Creating a test user with 15 posts
        */
        User::factory()->create([
            'email' => 'blogger@test.com',
            'password' => bcrypt('12345678'),
        ])->each(function ($user) {
            Post::factory(15)->create(['user_id' => $user->id]);
        });

        /*
        * Creating 12 users, each with 15 posts
        */
        User::factory(12)->create()->each(function ($user) {
            Post::factory(15)->create(['user_id' => $user->id]);
        });
    }
}
