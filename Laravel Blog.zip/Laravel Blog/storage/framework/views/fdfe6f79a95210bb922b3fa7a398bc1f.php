<footer>
    <p>&copy; <?php echo e(date('Y')); ?> - All rights reserved</p>
</footer><?php /**PATH /Users/silkcoder/Herd/Project to share/demo/Laravel Blog/resources/views/includes/footer.blade.php ENDPATH**/ ?>