<header>
    <nav>
        <a href="<?php echo e(url('.')); ?>" class="logo">Blogs</a>
        <?php if(auth()->guard()->check()): ?>
        <ul class="menu">
            <li><a href="" onclick="event.preventDefault(); document.getElementById('logoutForm').submit()">Logout</a>  </li>
            <li><a href="<?php echo e(route('posts.index')); ?>">My posts</a></li>        
            <form action="<?php echo e(route('logout')); ?>" id="logoutForm" method="post">
                <?php echo csrf_field(); ?>                
            </form>            
        </ul>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
        <ul class="menu">
            <li><a class="<?php echo e(request()->is('register') ? 'active' : ''); ?>" href="<?php echo e(route('register')); ?>">Register</a></li>
            <li><a class="<?php echo e(request()->is('login') ? 'active' : ''); ?>" href="<?php echo e(route('login')); ?>">Login</a></li>
        </ul>
        <?php endif; ?>
    </nav>
</header><?php /**PATH /Users/silkcoder/Herd/blog/resources/views/includes/header.blade.php ENDPATH**/ ?>