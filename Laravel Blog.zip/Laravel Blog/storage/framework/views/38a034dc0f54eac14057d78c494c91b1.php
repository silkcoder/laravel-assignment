<?php $__env->startSection('title', 'Edit post'); ?>


<?php $__env->startSection('content'); ?>
<div class="form-admin">
    <div class="main-admin">

        <div class="title">
            <h3>Edit post</h3>
            <a href="<?php echo e(route('posts.index')); ?>">
                <button class="link-btn">Posts</button>
            </a>
        </div>

        <?php if(Session::has('success')): ?>
        <div class="alert-success">
            <?php echo Session::get('success'); ?>

        </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
        <ul class="errors">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>

        <hr>

        <form action="<?php echo e(route('posts.update', $post->id)); ?>" method="POST" id="editPostForm">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <label for="title"> Title </label>
            <input type="text" id="title" name="title" value="<?php echo e(old('title', $post->title)); ?>" placeholder="Enter title">

            <label for="content"> post </label>
            <textarea rows="10" name="content" placeholder="Enter new post"><?php echo e(old('content', $post->content)); ?></textarea>

            <div class="wrap-admin">
                <button class="admin mr-8" type="submit"> Update </button>
                <button class="danger" type="button" onclick="deletePost()"> Delete</button>
            </div>
        </form>

        <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST" id="deleteForm">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/javascript/user/edit_post.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/silkcoder/Herd/blog/resources/views/user/edit.blade.php ENDPATH**/ ?>