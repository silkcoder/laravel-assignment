<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('content'); ?>

<div class="form">

    <div class="main">
        <h3>Register</h3>

        <?php if($errors->any()): ?>
        <ul class="errors">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>

        <form action="" id="registrationForm" method="post">
            <?php echo csrf_field(); ?>

            <label for="name">
                Name
            </label>
            <input type="text" id="name" value="<?php echo e(old('name')); ?>" name="name" placeholder="Enter your name">

            <label for="email">
                Email
            </label>
            <input type="text" id="email" value="<?php echo e(old('email')); ?>" name="email" placeholder="Enter your email address">

            <label for="password">
                Password
            </label>
            <input type="password" id="password" name="password" placeholder="Enter password">

            <label for="password">
                Confirm password
            </label>
            <input type="password" id="confirmPassword" name="password_confirmation" placeholder="Confirm password">

            <div class="wrap">
                <button type="submit"> Submit </button>
            </div>

        </form>
        <div>
            <span>
                Already registered? </span>
            <a href="<?php echo e(route('login')); ?>"> login </a>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/javascript/register.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/silkcoder/Herd/blog/resources/views/auth/register.blade.php ENDPATH**/ ?>