<?php $__env->startSection('title', 'Add new post'); ?>

<?php $__env->startSection('content'); ?>
<div class="form-admin">
    <div class="main-admin">
        
        <div class="title">
            <h3>Add new post</h3>
            <a class="button" href="<?php echo e(route('posts.index')); ?>">
                <button class="link-btn">Posts</button>
            </a>
        </div>


        <?php if($errors->any()): ?>
        <ul class="errors">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>

        <form action="<?php echo e(route('posts.store')); ?>" id="newPostForm" method="POST">
            <?php echo csrf_field(); ?>
            <label for="title"> Title </label>
            <input type="text" id="title" name="title" value="<?php echo e(old('title')); ?>" placeholder="Enter title">

            <label for="content"> post </label>
            <textarea rows="10" id="content" name="content" placeholder="Enter new post"><?php echo e(old('content')); ?></textarea>

            <div class="wrap-admin">
                <button class="admin mr-8" type="submit"> Submit </button>
            </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/javascript/user/add_post.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/silkcoder/Herd/blog/resources/views/user/create.blade.php ENDPATH**/ ?>