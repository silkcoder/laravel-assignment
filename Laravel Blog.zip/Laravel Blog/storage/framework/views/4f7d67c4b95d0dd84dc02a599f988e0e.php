<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>

<div class="posts">
    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="post">
        <h2 class="title">
            <a href="<?php echo e(route('post',['slug' => $post->slug])); ?>"><?php echo e($post->title); ?></a>
        </h2>
        <div class="post-meta">
            <span>
                <img src="assets/images/icon-calendar.png" class="mr-8" />
                <span> <?php echo e($post->created_at->format('dS M Y')); ?> </span>
            </span>
            <span>
                <img src="assets/images/icon-humen.png" class="mr-8" />
                <a href=<?php echo e(route('home',['uid' => $post->user->id])); ?>><?php echo e($post->user->name); ?></a>
            </span>
        </div>
        <div class="contents">
            <p> <?php echo e($post->excerpt()); ?> </p>
            </dv>
            <hr>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="post">
        <h3 class="sub-title">No posts found.</h3>
    </div>
    <?php endif; ?>

    <?php if($posts->count()): ?>
    <div class="pages">
        <?php echo e($posts->appends(Request::except('page'))->links()); ?>

    </div>    
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/silkcoder/Herd/Project to share/demo/Laravel Blog/resources/views/home.blade.php ENDPATH**/ ?>