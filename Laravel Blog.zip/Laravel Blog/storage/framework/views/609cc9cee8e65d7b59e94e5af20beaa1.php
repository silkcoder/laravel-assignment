<?php $__env->startSection('title', 'Edit post'); ?>


<?php $__env->startSection('content'); ?>
<div class="form-admin">
    <div class="main-admin">

        <div class="title">
            <h3>View post</h3>
            <a href="<?php echo e(route('posts.index')); ?>">
                <button class="link-btn">Posts</button>
            </a>
        </div>

        <hr>

        <div>
            <label for="title"> Title </label>
            <div><?php echo e($post->title); ?></div>

            <label for="content"> Post </label>
            <div><?php echo e($post->content); ?></div>
        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/silkcoder/Herd/blog/resources/views/user/show.blade.php ENDPATH**/ ?>