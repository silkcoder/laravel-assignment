<?php $__env->startSection('title', $post->title); ?>

<?php $__env->startSection('content'); ?>

<div class="posts">
    <div class="post">
        <h2 class="title">
            <?php echo e($post->title); ?>

        </h2>
        <div class="post-meta">
            <span>
                <img src="<?php echo e(asset('assets/images/icon-calendar.png')); ?>" class="mr-8" />
                <span> <?php echo e($post->created_at->format('dS M Y')); ?> </span>
            </span>
            <span>
                <img src="<?php echo e(asset('assets/images/icon-humen.png')); ?>" class="mr-8" />
                <a href=<?php echo e(route('home',['uid' => $post->user->id])); ?>><?php echo e($post->user->name); ?></a>
            </span>
        </div>
        <div class="contents">
            <p> <?php echo nl2br(e($post->content)); ?> </p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/silkcoder/Herd/blog/resources/views/post.blade.php ENDPATH**/ ?>