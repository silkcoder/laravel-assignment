<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>

<div class="form">

    <div class="main">
        <h3>Login</h3>

        <?php if($errors->any()): ?>
        <ul class="errors">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>

        <?php if(request()->has('msg') && request()->get('msg') == 'auth-required'): ?>
        <ul class="errors">
            <li>Please login to continue.</li>
        </ul>
        <?php endif; ?>

        <form action="<?php echo e(route('authentication')); ?>" id="loginForm" method="post">
            <?php echo csrf_field(); ?>

            <label for="email">
                Email
            </label>
            <input type="text" id="email" value="<?php echo e(old('email')); ?>" name="email" placeholder="Enter your email address">

            <label for="password">
                Password
            </label>
            <input type="password" id="password" name="password" placeholder="Enter password">


            <div class="wrap">
                <button type="submit"> Submit </button>
            </div>

        </form>
        <div>
            <span>
                Not registered? </span>
            <a href="<?php echo e(route('register')); ?>"> Register </a>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/javascript/login.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/silkcoder/Herd/blog/resources/views/auth/login.blade.php ENDPATH**/ ?>