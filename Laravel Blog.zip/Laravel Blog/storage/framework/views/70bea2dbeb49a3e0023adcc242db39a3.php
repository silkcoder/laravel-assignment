<footer>
    <p>&copy; <?php echo e(date('Y')); ?> - All rights reserved</p>
</footer><?php /**PATH /Users/silkcoder/Herd/blog/resources/views/includes/footer.blade.php ENDPATH**/ ?>