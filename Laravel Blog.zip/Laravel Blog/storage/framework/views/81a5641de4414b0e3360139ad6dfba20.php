<?php $__env->startSection('title', 'My posts'); ?>

<?php $__env->startSection('content'); ?>
<div class="form-admin">
    <div class="main-admin">
        <div class="title">
            <h3>Posts</h3>
            <a href="<?php echo e(route('posts.create')); ?>">
                <button class="link-btn">Add post</button>
            </a>
        </div>
        <?php if(Session::has('success')): ?>
        <div class="alert-success">
            <?php echo Session::get('success'); ?>

        </div>
        <?php endif; ?>
        <hr>
        <table id="data">
            <tr>
                <th>Title</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($post->title); ?></td>
                <td><?php echo e($post->created_at->format('dS M Y')); ?></td>
                <td>
                    <a href="<?php echo e(route('posts.edit', $post->id)); ?>">Edit</a> | <a href="<?php echo e(route('posts.show', $post->id)); ?>">View</a>                    
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3" align="center">No posts found.</td>
            </tr>
            <?php endif; ?>
        </table>
        <div class="pages">
            <?php echo e($posts->appends(Request::except('page'))->links()); ?>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/silkcoder/Herd/blog/resources/views/user/posts.blade.php ENDPATH**/ ?>