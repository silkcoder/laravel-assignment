@extends('layouts.master')
@section('title', $post->title)

@section('content')

<div class="posts">
    <div class="post">
        <h2 class="title">
            {{$post->title}}
        </h2>
        <div class="post-meta">
            <span>
                <img src="{{ asset('assets/images/icon-calendar.png') }}" class="mr-8" />
                <span> {{ $post->created_at->format('dS M Y')  }} </span>
            </span>
            <span>
                <img src="{{ asset('assets/images/icon-humen.png') }}" class="mr-8" />
                <a href={{ route('home',['uid' => $post->user->id]) }}>{{$post->user->name}}</a>
            </span>
        </div>
        <div class="contents">
            <p> {!! nl2br(e($post->content)) !!} </p>
        </div>
    </div>
</div>
@endsection