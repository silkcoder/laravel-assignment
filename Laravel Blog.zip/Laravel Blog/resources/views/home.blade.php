@extends('layouts.master')
@section('title', 'Home')
@section('content')

<div class="posts">
    @forelse($posts as $post)
    <div class="post">
        <h2 class="title">
            <a href="{{ route('post',['slug' => $post->slug]) }}">{{$post->title}}</a>
        </h2>
        <div class="post-meta">
            <span>
                <img src="assets/images/icon-calendar.png" class="mr-8" />
                <span> {{  $post->created_at->format('dS M Y')  }} </span>
            </span>
            <span>
                <img src="assets/images/icon-humen.png" class="mr-8" />
                <a href={{ route('home',['uid' => $post->user->id]) }}>{{$post->user->name}}</a>
            </span>
        </div>
        <div class="contents">
            <p> {{ $post->excerpt()}} </p>
            </dv>
            <hr>
        </div>
    </div>
    @empty
    <div class="post">
        <h3 class="sub-title">No posts found.</h3>
    </div>
    @endforelse

    @if($posts->count())
    <div class="pages">
        {{ $posts->appends(Request::except('page'))->links() }}
    </div>    
    @endif

</div>
@endsection