@extends('layouts.master')
@section('title', 'Register')

@section('content')

<div class="form">

    <div class="main">
        <h3>Register</h3>

        @if($errors->any())
        <ul class="errors">
            @foreach ($errors->all() as $error)
            <li>{{$error}}</li>
            @endforeach
        </ul>
        @endif

        <form action="" id="registrationForm" method="post">
            @csrf

            <label for="name">
                Name
            </label>
            <input type="text" id="name" value="{{old('name')}}" name="name" placeholder="Enter your name">

            <label for="email">
                Email
            </label>
            <input type="text" id="email" value="{{old('email')}}" name="email" placeholder="Enter your email address">

            <label for="password">
                Password
            </label>
            <input type="password" id="password" name="password" placeholder="Enter password">

            <label for="password">
                Confirm password
            </label>
            <input type="password" id="confirmPassword" name="password_confirmation" placeholder="Confirm password">

            <div class="wrap">
                <button type="submit"> Submit </button>
            </div>

        </form>
        <div>
            <span>
                Already registered? </span>
            <a href="{{route('login')}}"> login </a>

        </div>
    </div>
</div>
@endsection
@section('scripts')
<script src="{{asset('assets/javascript/register.js')}}"></script>
@endsection