@extends('layouts.master')
@section('title', 'Login')

@section('content')

<div class="form">

    <div class="main">
        <h3>Login</h3>

        @if($errors->any())
        <ul class="errors">
            @foreach ($errors->all() as $error)
            <li>{{$error}}</li>
            @endforeach
        </ul>
        @endif

        @if(request()->has('msg') && request()->get('msg') == 'auth-required')
        <ul class="errors">
            <li>Please login to continue.</li>
        </ul>
        @endIf

        <form action="{{ route('authentication') }}" id="loginForm" method="post">
            @csrf

            <label for="email">
                Email
            </label>
            <input type="text" id="email" value="{{old('email')}}" name="email" placeholder="Enter your email address">

            <label for="password">
                Password
            </label>
            <input type="password" id="password" name="password" placeholder="Enter password">


            <div class="wrap">
                <button type="submit"> Submit </button>
            </div>

        </form>
        <div>
            <span>
                Not registered? </span>
            <a href="{{route('register')}}"> Register </a>

        </div>
    </div>
</div>
@endsection

@section('scripts')
<script src="{{asset('assets/javascript/login.js')}}"></script>
@endsection