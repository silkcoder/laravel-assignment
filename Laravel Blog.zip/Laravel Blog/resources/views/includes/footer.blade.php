<footer>
    <p>&copy; {{ date('Y') }} - All rights reserved</p>
</footer>