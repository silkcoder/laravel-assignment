<header>
    <nav>
        <a href="{{url('.')}}" class="logo">Blogs</a>
        @auth
        <ul class="menu">
            <li><a href="" onclick="event.preventDefault(); document.getElementById('logoutForm').submit()">Logout</a>  </li>
            <li><a href="{{route('posts.index')}}">My posts</a></li>        
            <form action="{{route('logout')}}" id="logoutForm" method="post">
                @csrf                
            </form>            
        </ul>
        @endauth

        @guest
        <ul class="menu">
            <li><a class="{{ request()->is('register') ? 'active' : '' }}" href="{{route('register')}}">Register</a></li>
            <li><a class="{{ request()->is('login') ? 'active' : '' }}" href="{{route('login')}}">Login</a></li>
        </ul>
        @endguest
    </nav>
</header>