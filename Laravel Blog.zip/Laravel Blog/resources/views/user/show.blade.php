@extends('layouts.master')
@section('title', 'Edit post')


@section('content')
<div class="form-admin">
    <div class="main-admin">

        <div class="title">
            <h3>View post</h3>
            <a href="{{ route('posts.index') }}">
                <button class="link-btn">Posts</button>
            </a>
        </div>

        <hr>

        <div>
            <label for="title"> Title </label>
            <div>{{$post->title}}</div>

            <label for="content"> Post </label>
            <div>{{$post->content}}</div>
        </div>


    </div>
</div>
@endsection