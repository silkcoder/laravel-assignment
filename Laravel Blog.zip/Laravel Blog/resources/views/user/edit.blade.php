@extends('layouts.master')
@section('title', 'Edit post')


@section('content')
<div class="form-admin">
    <div class="main-admin">

        <div class="title">
            <h3>Edit post</h3>
            <a href="{{ route('posts.index') }}">
                <button class="link-btn">Posts</button>
            </a>
        </div>

        @if (Session::has('success'))
        <div class="alert-success">
            {!! Session::get('success') !!}
        </div>
        @endif

        @if($errors->any())
        <ul class="errors">
            @foreach ($errors->all() as $error)
            <li>{{$error}}</li>
            @endforeach
        </ul>
        @endif

        <hr>

        <form action="{{route('posts.update', $post->id)}}" method="POST" id="editPostForm">
            @method('PUT')
            @csrf
            <label for="title"> Title </label>
            <input type="text" id="title" name="title" value="{{old('title', $post->title)}}" placeholder="Enter title">

            <label for="content"> post </label>
            <textarea rows="10" name="content" placeholder="Enter new post">{{old('content', $post->content)}}</textarea>

            <div class="wrap-admin">
                <button class="admin mr-8" type="submit"> Update </button>
                <button class="danger" type="button" onclick="deletePost()"> Delete</button>
            </div>
        </form>

        <form action="{{route('posts.destroy', $post->id)}}" method="POST" id="deleteForm">
            @method('DELETE')
            @csrf
        </form>

    </div>
</div>
@endsection
@section('scripts')
<script src="{{asset('assets/javascript/user/edit_post.js')}}"></script>
@endsection