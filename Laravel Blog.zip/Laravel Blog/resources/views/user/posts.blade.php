@extends('layouts.master')
@section('title', 'My posts')

@section('content')
<div class="form-admin">
    <div class="main-admin">
        <div class="title">
            <h3>Posts</h3>
            <a href="{{ route('posts.create') }}">
                <button class="link-btn">Add post</button>
            </a>
        </div>
        @if (Session::has('success'))
        <div class="alert-success">
            {!! Session::get('success') !!}
        </div>
        @endif
        <hr>
        <table id="data">
            <tr>
                <th>Title</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
            @forelse($posts as $post)
            <tr>
                <td>{{$post->title}}</td>
                <td>{{$post->created_at->format('dS M Y')}}</td>
                <td>
                    <a href="{{route('posts.edit', $post->id)}}">Edit</a> | <a href="{{route('posts.show', $post->id)}}">View</a>                    
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="3" align="center">No posts found.</td>
            </tr>
            @endforelse
        </table>
        <div class="pages">
            {{ $posts->appends(Request::except('page'))->links() }}
        </div>
    </div>

</div>
@endsection