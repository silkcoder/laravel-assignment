@extends('layouts.master')
@section('title', 'Add new post')

@section('content')
<div class="form-admin">
    <div class="main-admin">
        
        <div class="title">
            <h3>Add new post</h3>
            <a class="button" href="{{ route('posts.index') }}">
                <button class="link-btn">Posts</button>
            </a>
        </div>


        @if($errors->any())
        <ul class="errors">
            @foreach ($errors->all() as $error)
            <li>{{$error}}</li>
            @endforeach
        </ul>
        @endif

        <form action="{{route('posts.store')}}" id="newPostForm" method="POST">
            @csrf
            <label for="title"> Title </label>
            <input type="text" id="title" name="title" value="{{old('title')}}" placeholder="Enter title">

            <label for="content"> post </label>
            <textarea rows="10" id="content" name="content" placeholder="Enter new post">{{old('content')}}</textarea>

            <div class="wrap-admin">
                <button class="admin mr-8" type="submit"> Submit </button>
            </div>

        </form>
    </div>
</div>
@endsection
@section('scripts')
<script src="{{asset('assets/javascript/user/add_post.js')}}"></script>
@endsection