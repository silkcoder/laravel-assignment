    //get the registration form
    const loginForm = document.getElementById("loginForm");

    //array to store error messages to list
    const errorMessages = Array();

    //listen for form submission
    loginForm.addEventListener("submit", function(event) {

        //prevent form submission
        event.preventDefault();

        //get form elements
        const {
            email,
            password,
        } = loginForm.elements;

        //clear error messages
        errorMessages.length = 0;

        //validate email, make sure it is not empty
        if (!email.value.trim() || !password.value.trim()) {
            errorMessages.push('Email and password fields required');
        }

        //no errors found, submit the form
        if (errorMessages.length === 0) {
            loginForm.submit();
            return
        }

        //display error messages
        displayError();
    });

    /**
     * Display error messages
     */
    function displayError(message) {

        //remove existing listed error messages
        const existingErrors = document.querySelector('.errors');
        if (existingErrors) {
            existingErrors.remove();
        }

        //create a new ul element
        const ul = document.createElement('ul');

        //add a class to the ul element
        ul.classList.add('errors');

        //add each error message to the ul element
        errorMessages.forEach(message => {
            const li = document.createElement('li');
            li.textContent = message;
            ul.appendChild(li);
        });

        //list the created error messages
        loginForm.prepend(ul);
    }

    /**
     * Check if the email is valid
     * @param {string} email
     * @returns {boolean}
     */
    function isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }