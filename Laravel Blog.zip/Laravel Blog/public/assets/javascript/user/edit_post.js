 //get the editPostForm form
 const editPostForm = document.getElementById("editPostForm");

 //array to store error messages to list
 const errorMessages = Array();

 //listen for form submission
 editPostForm.addEventListener("submit", function(event) {

     //prevent form submission
     event.preventDefault();

     //get form elements
     const {
         title,
         content
     } = editPostForm.elements;

     //clear error messages
     errorMessages.length = 0;

     //validate name, make sure it is not empty
     if (!title.value.trim()) {
         errorMessages.push("The title field is required.");
     }

     //validate email, make sure it is not empty
     if (!content.value.trim()) {
         errorMessages.push("The content field is required.");
     }


     //no errors found, submit the form
     if (errorMessages.length === 0) {
         editPostForm.submit();
         return
     }

     //display error messages
     displayError();
 });

 /**
  * Display error messages
  */
 function displayError(message) {

     //remove existing listed error messages
     const existingErrors = document.querySelector('.errors');
     if (existingErrors) {
         existingErrors.remove();
     }

     //create a new ul element
     const ul = document.createElement('ul');

     //add a class to the ul element
     ul.classList.add('errors');

     //add each error message to the ul element
     errorMessages.forEach(message => {
         const li = document.createElement('li');
         li.textContent = message;
         ul.appendChild(li);
     });

     //list the created error messages
     editPostForm.prepend(ul);
 }

 function deletePost() {
     if (confirm('Are you sure you want to delete this post?')) {
         document.getElementById('deleteForm').submit();
     }
 }