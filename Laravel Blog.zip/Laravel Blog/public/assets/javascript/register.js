//get the registration form
const registrationForm = document.getElementById("registrationForm");

//array to store error messages to list
const errorMessages = Array();

//listen for form submission
registrationForm.addEventListener("submit", function (event) {

    //prevent form submission
    event.preventDefault();

    //get form elements
    const {
        name,
        email,
        password,
        confirmPassword
    } = registrationForm.elements;

    //clear error messages
    errorMessages.length = 0;

    //validate name, make sure it is not empty
    if (!name.value.trim()) {
        errorMessages.push("The name field is required.");
    }

    //validate email, make sure it is not empty
    if (!email.value.trim()) {
        errorMessages.push("The email field is required.");
    }

    //validate email, make sure it is a valid email address
    if (email.value.trim() && !isValidEmail(email.value.trim())) {
        errorMessages.push("The email field must be a valid email address.");
    }

    //validate password, make sure it is not empty
    if (!password.value.trim()) {
        errorMessages.push("The password field is required.");
    }

    //validate password, make sure it is at least 8 characters
    if (password.value.trim() && password.value.trim().length < 8) {
        errorMessages.push("The password field must be at least 8 characters.");
    }

    //validate password confirmation, compare with password
    if (password.value.trim() && password.value.trim() !== confirmPassword.value.trim()) {
        errorMessages.push("The password field confirmation does not match.");
    }

    //no errors found, submit the form
    if (errorMessages.length === 0) {
        registrationForm.submit();
        return
    }

    //display error messages
    displayError();
});

/**
 * Display error messages
 */
function displayError(message) {

    //remove existing listed error messages
    const existingErrors = document.querySelector('.errors');
    if (existingErrors) {
        existingErrors.remove();
    }

    //create a new ul element
    const ul = document.createElement('ul');

    //add a class to the ul element
    ul.classList.add('errors');

    //add each error message to the ul element
    errorMessages.forEach(message => {
        const li = document.createElement('li');
        li.textContent = message;
        ul.appendChild(li);
    });

    //list the created error messages
    registrationForm.prepend(ul);
}

/**
 * Check if the email is valid
 * @param {string} email
 * @returns {boolean}
 */
function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
