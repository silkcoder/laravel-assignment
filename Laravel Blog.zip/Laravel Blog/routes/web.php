<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Auth\RegistrationController;
use App\Http\Controllers\User\PostController;
use App\Http\Middleware\CheckAuthenticated;

//routes for all users
Route::get('/', HomeController::class)->name('home');
Route::get('/post/{slug}', [HomeController::class, 'post'])->name('post');

//auth and registration routes, only unauthenticated users can access these routes
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'loginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'authenticate'])->name('authentication');
    Route::get('/register', [RegistrationController::class, 'create'])->name('register');
    Route::post('/register', [RegistrationController::class, 'store'])->name('registration');
});

//logout route
Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware(CheckAuthenticated::class);

//user routes to manage posts, only authenticated users can access these routes
Route::prefix('user')->middleware(CheckAuthenticated::class)->group(function () {    
    Route::resource('posts', PostController::class);
});